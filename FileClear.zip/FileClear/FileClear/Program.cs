﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;

namespace FileClear
{
    class Program
    {
        static void Main(string[] args)
        {
            int threshold = 0;
            List<string> pathstoclear = new List<string>();
            Setup(ref threshold, pathstoclear);
            while (true)
            {
                DriveInfo maindrive = new DriveInfo("/");
                int discusage = (int)(((float)maindrive.AvailableFreeSpace / (float)maindrive.TotalSize) * 100);
                if (discusage > threshold)
                {
                    ClearFolders(pathstoclear);
                }
                Thread.Sleep(5000);
            }
        }

        static void Setup(ref int threshold, List<string> pathstoclear)
        {
            string[] lines = { };
            try
            {
                lines = File.ReadAllLines("/home/test.txt");
            }
            catch
            {
                Console.WriteLine("Error reading config file");
            }
            if (lines.Length > 0)
            {
                try
                {
                    threshold = Int32.Parse(lines[0]);
                }
                catch
                {
                    Console.WriteLine("Error reading threshold");
                }
                for (int i = 1; i < lines.Length; i++)
                {
                    pathstoclear.Add(lines[i]);
                }
                if (pathstoclear.Count == 0)
                {
                    Console.WriteLine("No folders to clear were provided");
                }
            }
        }

        static void ClearFolders(List<string> pathstoclear)
        {
            foreach (string path in pathstoclear)
            {
                try
                {
                    System.IO.DirectoryInfo folder = new DirectoryInfo(path);
                    foreach (FileInfo file in folder.EnumerateFiles())
                    {
                        file.Delete();
                    }
                    foreach (DirectoryInfo dir in folder.EnumerateDirectories())
                    {
                        dir.Delete(true);
                    }
                }
                catch
                {
                    Console.WriteLine("Error cleaning out " + path);
                }
            }
        }
    }
}
